//
//  YocSDK.h
//  VisxSDK
//
//  Created by Aleksandar Jovanov on 3/19/20.
//  Copyright © 2020 YOC AG. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for YocSDK.
FOUNDATION_EXPORT double YocSDKVersionNumber;
//! Project version string for YocSDK.
FOUNDATION_EXPORT const unsigned char YocSDKVersionString[];
#import "OMIDImports.h"
#import <VisxSDK/MediationLoader.h>

